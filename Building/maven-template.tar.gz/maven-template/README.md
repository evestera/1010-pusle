# Eksempel på bruk av Maven

### Kjøre tester

    mvn test

### Kjøre programmet

    mvn package
    java -cp target/my-app-0.1.jar org.example.Main

### Rydde opp før levering o.l.

    mvn clean
